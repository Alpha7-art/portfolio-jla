document.querySelectorAll('a[href^="#"]').forEach(link => {
  link.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({
        behavior: 'smooth'
      });
    }
  });
});
window.addEventListener('scroll', () => {
  const fills = document.querySelectorAll('.progress-fill');
  fills.forEach(fill => {
    const width = fill.getAttribute('style').match(/\d+/)[0];
    fill.style.width = width + '%';
  });
});